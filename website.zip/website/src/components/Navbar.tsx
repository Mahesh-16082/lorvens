
function Navbar() {
  return (
    <nav className="navbar">
      <div className="container nav">

        {/* Logo / Brand */}
        <a href="#" className="brand">
          <img
            src="/assets/logo.png"
            alt="Lorvens Club"
            className="nav-logo"
          />
          <span>LORVENS CLUB</span>
        </a>

        {/* Navigation Links */}
        <div className="links">
          <a href="#about">ABOUT</a>
          <a href="#cards">MEMBERSHIP</a>
          <a href="#amenities">AMENITIES</a>
          <a href="#gallery">GALLERY</a>
          <a href="#contact">CONTACT</a>
        </div>

        {/* Enquiry Button */}
        <a className="button outline" href="#contact">
          ENQUIRE NOW
        </a>

      </div>
    </nav>
  );
}

export default Navbar;
