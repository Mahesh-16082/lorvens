const gallery = [
  ['reception', '/assets/gallery-lobby.png', 'Lorvens Club luxury reception and lobby', 'Club Reception'],
  ['gym', '/assets/gallery-gym.png', 'Lorvens Club modern gym', 'Fitness Centre'],
  ['pool', '/assets/gallery-pool.png', 'Lorvens Club indoor swimming pool', 'Swimming Pool'],
  ['restaurant', '/assets/gallery-restaurant.png', 'Lorvens Club restaurant', 'Fine Dining'],
  ['games', '/assets/gallery-games.png', 'Lorvens Club indoor games room', 'Indoor Games'],
  ['cinema', '/assets/gallery-lounge.png', 'Lorvens Club business lounge', 'Business Lounge'],
  ['spa', '/assets/hero-club-exterior.png', 'Lorvens Club exterior at night', 'Lorvens Club'],
];

export default function Gallery() {
  return (
    <section className="gallery" id="gallery">
      <div className="container center">
        <div className="section-label">A GLIMPSE INTO THE LORVENS LIFESTYLE</div>
        <h2>Discover the Lorvens Experience</h2>
        <p className="intro-text">Explore the premium spaces of Lorvens Club — from elegant arrivals and fitness to leisure, dining and recreation.</p>
        <div className="gallery-grid">
          {gallery.map(([layout, src, alt, title]) => (
            <article className={`gallery-card ${layout}`} key={layout}>
              <img src={src} alt={alt} />
              <span className="gallery-title">{title}</span>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
