
function About() {
  return (
    <section className="intro" id="about">
      <div className="container intro-grid">
        <div>
          <div className="section-label">
            LORVENS CLUB • TIRUPATI
          </div>

          <h2>
            More Than a Club.
            <br />
            A Better Lifestyle.
          </h2>

          <p>
            Lorvens Club is envisioned as a premium lifestyle
            destination inspired by comfort, wellness, nature
            and meaningful connections. From recreation and
            dining to wellness and exclusive member experiences,
            every space is designed to feel special.
          </p>
        </div>

        <div className="address-card">
          <h3>VISIT OUR CLUB</h3>

          <p>
            LORNVENS CLUB
            <br />
            S.No: 383, Vemuru,
            <br />
            Tirupati -517503,
            <br />
            Andhra Pradesh.
            <br />
            <br />
            www.lorvensclub.com
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;
