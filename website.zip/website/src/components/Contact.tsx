export default function Contact() {
  return (
    <section className="contact" id="contact">
      <div className="container contact-grid">
        <div>
          <div className="section-label">MEMBERSHIP ENQUIRIES</div>
          <h2>Be Among the First to Experience Lorvens Club</h2>
          <p>This is a coming soon project. Connect with us for membership information, launch updates and exclusive early access opportunities.</p>
          <p><strong>Website:</strong> <a href="https://www.lorvensclub.com">www.lorvensclub.com</a></p>
          <p><strong>Email:</strong> <a href="mailto:support@lorvensclub.com">support@lorvensclub.com</a></p>
        </div>
        <div className="contact-box">
          <h3 className="serif" style={{ fontSize: 28, marginTop: 0, color: '#f0cf78' }}>COMING SOON</h3>
          <p>A privileged destination is taking shape in Tirupati.</p>
          <p><strong>LORNVENS CLUB</strong><br />S.No: 383, Vemuru,<br />Tirupati -517503,<br />Andhra Pradesh.</p>
          <p><a href="https://www.lorvensclub.com">www.lorvensclub.com</a><br /><a href="mailto:support@lorvensclub.com">support@lorvensclub.com</a></p>
        </div>
      </div>
    </section>
  );
}
