const benefits = [
  ['♛', 'Exclusive Free Stays', 'All Club Members can enjoy a complimentary 3-day stay with their family once every year.'],
  ['📅', 'Preferred Bookings', 'Advance reservation windows for club events, stays and exclusive services.'],
  ['%', 'Member Discounts', 'Special member rates and discounts on dining, stays and recreational activities.'],
  ['🎧', 'Dedicated Support', 'Personalized customer support for all member assistance and inquiries.'],
  ['🎁', 'Referral Rewards Program', 'Earn exclusive member rewards and club vouchers for every successful new member referral.'],
];

export default function Benefits() {
  return (
    <section className="benefits" id="benefits">
      <div className="container center">
        <div className="section-label">MEMBERSHIP EXPERIENCE</div>
        <h2>Club Benefits &amp; Privileges</h2>
        <p className="benefits-intro">A Lorvens Club membership is designed to offer priority, convenience, savings and rewarding experiences across the club lifestyle.</p>
        <div className="benefit-grid">
          {benefits.map(([icon, title, description]) => (
            <div className="benefit-card" key={title}>
              <div className="benefit-icon">{icon}</div>
              <h3>{title}</h3>
              <p>{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
