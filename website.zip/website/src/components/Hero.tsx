
function Hero() {
  return (
    <header className="hero">
      <div className="hero-bg"></div>

      <div className="container hero-content">
        <div className="hero-copy">
          <img
            src="/assets/logo.png"
            alt="Lorvens Club logo"
            className="logo-mark"
          />

          <div className="coming">
            COMING SOON
          </div>

          <h1>
            A NEW PRIVILEGED CIRCLE AWAITS
          </h1>

          <p>
            Wellness. Comfort. Nature. A thoughtfully designed club
            destination where premium experiences, leisure and
            meaningful moments come together.
          </p>

          <div className="hero-actions">
            <a className="button" href="#cards">
              EXPLORE MEMBERSHIP
            </a>

            <a className="button outline" href="#about">
              DISCOVER LORVENS
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Hero;
