
function Membership() {
  return (
    <section className="cards" id="cards">
      <div className="container center">
        <div
          className="section-label"
          style={{ color: "#f0cf78" }}
        >
          MEMBERSHIP PREVIEW
        </div>

        <h2>Your Privilege, In Your Hand</h2>

        <p className="sub">
          An exclusive Lorvens Club membership card designed in a
          rich gold finish, representing access to a world of
          premium experiences and privileges.
        </p>

        <div className="card-preview">
          <div>
            <div className="member-card">
              <img
                src="/assets/membership-card-front.png"
                alt="Lorvens Club membership card front"
              />
            </div>
            <div className="card-caption">
              MEMBERSHIP CARD • FRONT
            </div>
          </div>

          <div>
            <div className="member-card">
              <img
                src="/assets/membership-card-back.png"
                alt="Lorvens Club membership card back"
              />
            </div>
            <div className="card-caption">
              MEMBERSHIP CARD • BACK
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Membership;
