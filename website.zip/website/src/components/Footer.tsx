
export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-content">
        <div className="footer-brand">
          <h3>LORVENS CLUB</h3>
          <p>WELLNESS. COMFORT. NATURE.</p>
        </div>

        <div className="footer-bottom">
          <p>© 2026 LORVENS CLUB. ALL RIGHTS RESERVED.</p>
          <p>COMING SOON</p>
        </div>
      </div>
    </footer>
  );
}
