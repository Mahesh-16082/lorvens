import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Membership from './components/Membership';
import Amenities from './components/Amenities';
import Benefits from './components/Benefits';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Membership />
        <Amenities />
        <Benefits />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
